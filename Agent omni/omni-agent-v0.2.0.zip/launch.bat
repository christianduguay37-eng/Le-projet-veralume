@echo off
title OMNI AGENT - Launcher
color 0B

echo.
echo   ╔═══════════════════════════════════════╗
echo   ║       OMNI AGENT — Launcher           ║
echo   ║  Double STRIC · Local · VERALUME      ║
echo   ╚═══════════════════════════════════════╝
echo.

:: ═══════════════════════════════════════════
:: CONFIGURATION — modifie ces chemins
:: ═══════════════════════════════════════════

set LLAMA_DIR=C:\Users\Christian\Desktop\llama-b8140-bin-win-vulkan-x64
set MODEL=%LLAMA_DIR%\dolphin-2.9-llama3-8b.Q4_K_M.gguf
set AGENT_DIR=C:\Users\Christian\Desktop\Agent omni\omni-agent-v0.2.0
set LLAMA_PORT=8080
set WEB_PORT=8888
set CTX_SIZE=8192
set GPU_LAYERS=99

:: ═══════════════════════════════════════════
:: Vérifications
:: ═══════════════════════════════════════════

if not exist "%LLAMA_DIR%\llama-server.exe" (
    echo [ERREUR] llama-server.exe introuvable dans:
    echo   %LLAMA_DIR%
    echo.
    echo Modifie LLAMA_DIR dans ce fichier .bat
    pause
    exit /b 1
)

if not exist "%MODEL%" (
    echo [ERREUR] Modele introuvable:
    echo   %MODEL%
    echo.
    echo Modifie MODEL dans ce fichier .bat
    pause
    exit /b 1
)

if not exist "%AGENT_DIR%\web_server.py" (
    echo [ERREUR] Agent introuvable dans:
    echo   %AGENT_DIR%
    echo.
    echo Modifie AGENT_DIR dans ce fichier .bat
    pause
    exit /b 1
)

:: ═══════════════════════════════════════════
:: Vérifier aiohttp
:: ═══════════════════════════════════════════

python -c "import aiohttp" 2>nul
if errorlevel 1 (
    echo [INFO] Installation de aiohttp...
    pip install aiohttp --quiet
    if errorlevel 1 (
        echo [ERREUR] Impossible d'installer aiohttp
        pause
        exit /b 1
    )
)

:: ═══════════════════════════════════════════
:: Tuer les anciens processus (si relance)
:: ═══════════════════════════════════════════

taskkill /f /im llama-server.exe 2>nul
timeout /t 1 /nobreak >nul

:: ═══════════════════════════════════════════
:: Lancer llama-server
:: ═══════════════════════════════════════════

echo [1/3] Demarrage llama-server...
echo       Modele: %MODEL%
echo       GPU layers: %GPU_LAYERS%
echo       Context: %CTX_SIZE%
echo.

start "LLAMA-SERVER" /min cmd /c "cd /d "%LLAMA_DIR%" && llama-server.exe -m "%MODEL%" -c %CTX_SIZE% --port %LLAMA_PORT% -ngl %GPU_LAYERS% 2>&1"

:: ═══════════════════════════════════════════
:: Attendre que llama-server soit prêt
:: ═══════════════════════════════════════════

echo [2/3] Attente du serveur...
set /a TRIES=0
set /a MAX_TRIES=30

:wait_loop
timeout /t 2 /nobreak >nul
set /a TRIES+=1

:: Tester si le port répond
powershell -command "try { $r = Invoke-WebRequest -Uri 'http://localhost:%LLAMA_PORT%/health' -TimeoutSec 2 -ErrorAction Stop; exit 0 } catch { exit 1 }" 2>nul
if %errorlevel% equ 0 goto server_ready

if %TRIES% geq %MAX_TRIES% (
    echo [ERREUR] llama-server n'a pas demarre apres 60 secondes
    echo Verifie la fenetre llama-server pour les erreurs
    pause
    exit /b 1
)

echo       ... tentative %TRIES%/%MAX_TRIES%
goto wait_loop

:server_ready
echo       Serveur pret!
echo.

:: ═══════════════════════════════════════════
:: Lancer l'agent web
:: ═══════════════════════════════════════════

echo [3/3] Demarrage interface web...
echo       http://localhost:%WEB_PORT%
echo.

:: Ouvrir le navigateur après 2 secondes
start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:%WEB_PORT%"

:: Lancer le web server (au premier plan — Ctrl+C pour arrêter)
echo ═══════════════════════════════════════════
echo   OMNI AGENT actif
echo   Interface: http://localhost:%WEB_PORT%
echo   Substrat:  http://localhost:%LLAMA_PORT%
echo.
echo   Ctrl+C pour tout arreter
echo ═══════════════════════════════════════════
echo.

cd /d "%AGENT_DIR%"
python web_server.py --port %WEB_PORT%

:: ═══════════════════════════════════════════
:: Nettoyage à la fermeture
:: ═══════════════════════════════════════════

echo.
echo Arret de llama-server...
taskkill /f /im llama-server.exe 2>nul
echo Termine.
pause
